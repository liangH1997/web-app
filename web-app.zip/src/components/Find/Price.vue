<!-- Price -->
<template>
<h3>发现优惠啦！！</h3>
</template>

<script>
export default {

}
</script>
<style scoped>

</style>