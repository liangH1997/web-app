<template>
  <div class="app">
    <router-view></router-view>
    
  </div>
</template>

<script>

export default {
  name: 'App',
  mounted : function(){
    // console.log(this.$store)
  }
}
</script>

<style>
*{
  padding: 0;
  margin: 0;
}
body{
  background-color: #F0F2F5;
}

html,body,ul,li,ol,dl,dd,dt,p,h1,h2,h3,h4,h5,h6,form,fieldset,legend,img,input{
    margin:0;
    padding:0;
}
h1,h2,h3,h4,h5,h6{
    font-size:16px;
    font-weight: normal;
}
ul,ol,li{
    list-style:none;
}
a,u{
    text-decoration: none;
}
b,strong{
    font-weight: normal;
}
em,i{
    font-style:normal;
}
img{
    border:0;
    display:block;
    /*清除图片下面的大于3px的间距*/
}
input{
    outline:none;
}
.clear_fix:after{
    content:".";
    clear:both;
    display:block;
    height:0;
    overflow:hidden;
    visibility: hidden;
}
.clear_fix{
    zoom:1;
}

</style>
